package pe.scotiabank.telebanking.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import pe.com.scotiabank.tbk.admin.trama.input.TRSAInput;

public class Main {
	
	
	private static final Logger LOG = LoggerFactory.getLogger(Main.class);
	
	public static void main(String[] args) {
		
		TRSAInput trsa = new TRSAInput();
		trsa.setContract("0000000043");
		trsa.setUserCode("00000001");
		trsa.setBtAccount("0000012345678901");
		LOG.info("->"+trsa+"<-");
	}
}
