package pe.com.scotiabank.tbk.admin.trama.file;

import pe.com.scotiabank.tbk.admin.trama.util.Body;

public class TRPCUserInfoFileOutput implements Body {
	
	// Datos de usuario
	private String userCode;
	private String completeName;
	private String email;
	private String phone;
	private String userType;
	private String userDescription;
	
	public static final int TBK_TRPC_USERCODE_LENGHT = 3;
	public static final int TBK_TRPC_COMPLETENAME_LENGHT = 30;
	public static final int TBK_TRPC_EMAIL_LENGHT = 60;
	public static final int TBK_TRPC_PHONE_LENGHT = 20;
	public static final int TBK_TRPC_USERTYPE_LENGHT = 1;
	public static final int TBK_TRPC_USERDESCRIPTION_LENGHT = 14;
	
	public TRPCUserInfoFileOutput(String line) {
		setStringBody(line);
	}
	
	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getCompleteName() {
		return completeName;
	}

	public void setCompleteName(String completeName) {
		this.completeName = completeName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserDescription() {
		return userDescription;
	}

	public void setUserDescription(String userDescription) {
		this.userDescription = userDescription;
	}

	@Override
	public String getStringBody() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setStringBody(String output) {
		int i=3;
		setUserCode(output.substring(i, i+=TBK_TRPC_USERCODE_LENGHT));
		setCompleteName(output.substring(i, i+=TBK_TRPC_COMPLETENAME_LENGHT));
		setEmail(output.substring(i, i+=TBK_TRPC_EMAIL_LENGHT));
		setPhone(output.substring(i, i+=TBK_TRPC_PHONE_LENGHT));
		setUserType(output.substring(i, i+=TBK_TRPC_USERTYPE_LENGHT));
		setUserDescription(output.substring(i, i+=TBK_TRPC_USERDESCRIPTION_LENGHT));
	}

	@Override
	public String toString() {
		return "TRPCUserInfoFileOutput [userCode=" + userCode + ", completeName=" + completeName + ", email=" + email
				+ ", phone=" + phone + ", userType=" + userType + ", userDescription=" + userDescription + "]\n";
	}
}
