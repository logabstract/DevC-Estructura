package pe.com.scotiabank.tbk.admin.trama.file;

import pe.com.scotiabank.tbk.admin.trama.util.Body;

public class TRPCUserAutonomiesFileOutput implements Body {

	//Autonomias
	private String user;
	private String paymentType;
	private String amountPEN;
	private String amountUSD;
	private String onlySignIndicator;
	private String jointIndicator;
	private String crossRefIndicator;
	
	public static final int TBK_TRPC_USER_LENGHT = 3;
	public static final int TBK_TRPC_PAYMENTTYPE_LENGHT = 2;
	public static final int TBK_TRPC_AMOUNTPEN_LENGHT = 15;
	public static final int TBK_TRPC_AMOUNTUSD_LENGHT = 15;
	public static final int TBK_TRPC_ONLYSIGNINDICATOR_LENGHT = 1;
	public static final int TBK_TRPC_JOINTINDICATOR_LENGHT = 1;
	public static final int TBK_TRPC_CROSSREFINDICATOR_LENGHT = 1;
	
	public TRPCUserAutonomiesFileOutput(String line) {
		setStringBody(line);
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getAmountPEN() {
		return amountPEN;
	}

	public void setAmountPEN(String amountPEN) {
		this.amountPEN = amountPEN;
	}

	public String getAmountUSD() {
		return amountUSD;
	}

	public void setAmountUSD(String amountUSD) {
		this.amountUSD = amountUSD;
	}

	public String getOnlySignIndicator() {
		return onlySignIndicator;
	}

	public void setOnlySignIndicator(String onlySignIndicator) {
		this.onlySignIndicator = onlySignIndicator;
	}

	public String getJointIndicator() {
		return jointIndicator;
	}

	public void setJointIndicator(String jointIndicator) {
		this.jointIndicator = jointIndicator;
	}

	public String getCrossRefIndicator() {
		return crossRefIndicator;
	}

	public void setCrossRefIndicator(String crossRefIndicator) {
		this.crossRefIndicator = crossRefIndicator;
	}

	@Override
	public String getStringBody() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setStringBody(String output) {
		int i=3;
		setUser(output.substring(i, i+=TBK_TRPC_USER_LENGHT));
		setPaymentType(output.substring(i, i+=TBK_TRPC_PAYMENTTYPE_LENGHT));
		setAmountPEN(output.substring(i, i+=TBK_TRPC_AMOUNTPEN_LENGHT));
		setAmountUSD(output.substring(i, i+=TBK_TRPC_AMOUNTUSD_LENGHT));
		setOnlySignIndicator(output.substring(i, i+=TBK_TRPC_ONLYSIGNINDICATOR_LENGHT));
		setJointIndicator(output.substring(i, i+=TBK_TRPC_JOINTINDICATOR_LENGHT));
		setCrossRefIndicator(output.substring(i, i+=TBK_TRPC_CROSSREFINDICATOR_LENGHT));
	}

	@Override
	public String toString() {
		return "TRPCUserAutonomiesFileOutput [user=" + user + ", paymentType=" + paymentType + ", amountPEN="
				+ amountPEN + ", amountUSD=" + amountUSD + ", onlySignIndicator=" + onlySignIndicator
				+ ", jointIndicator=" + jointIndicator + ", crossRefIndicator=" + crossRefIndicator + "]\n";
	}

}
