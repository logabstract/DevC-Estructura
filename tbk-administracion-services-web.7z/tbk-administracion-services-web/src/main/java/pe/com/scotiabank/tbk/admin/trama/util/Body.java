package pe.com.scotiabank.tbk.admin.trama.util;

public interface Body {
	
	public String getStringBody();
	
	public void setStringBody(String output);

}
