package pe.com.scotiabank.tbk.admin.trama.input;

import org.apache.commons.lang3.StringUtils;

import pe.com.scotiabank.tbk.admin.trama.util.Functions;

public class TRSAInput {

	private String contract;
	private String userCode;
	private String btAccount;
	
	public TRSAInput() {
		setContract(StringUtils.SPACE);
		setUserCode(StringUtils.SPACE);
		setBtAccount(StringUtils.SPACE);
	}

	public TRSAInput(String contract, String userCode, String btAccount) {
		setContract(contract);
		setUserCode(userCode);
		setBtAccount(btAccount);
	}

	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = Functions.truncateLeftWithZeros(contract, 5);
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = Functions.truncateLeftWithZeros(userCode, 3);
	}

	public String getBtAccount() {
		return btAccount;
	}

	public void setBtAccount(String btAccount) {
		this.btAccount = Functions.truncateRightWithSpaces(btAccount, 9);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(contract).append(userCode).append(btAccount);
		return builder.toString();
	}

}
