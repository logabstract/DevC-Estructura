package pe.com.scotiabank.tbk.admin.trama.output;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import pe.com.scotiabank.tbk.admin.trama.file.TRPCUserAutonomiesFileOutput;
import pe.com.scotiabank.tbk.admin.trama.file.TRPCUserCrossReferencesFileOutput;
import pe.com.scotiabank.tbk.admin.trama.file.TRPCUserInfoFileOutput;
import pe.com.scotiabank.tbk.admin.trama.file.TRPCUserRestrictionsFileOutput;
import pe.com.scotiabank.tbk.admin.trama.util.Body;
import pe.com.scotiabank.tbk.admin.trama.util.TramaFileReader;

public class TRPCOutput implements Body, TramaFileReader{
	
	private String sessionName;
	private List<TRPCUserInfoFileOutput> trpcUserInfoFileOutput = new ArrayList<>();
	private List<TRPCUserRestrictionsFileOutput> trpcUserRestrictionsFileOutput = new ArrayList<>();
	private List<TRPCUserAutonomiesFileOutput> trpcUserAutonomiesFileOutput = new ArrayList<>();
	private List<TRPCUserCrossReferencesFileOutput> trpcUserCrossReferenceFileOutput = new ArrayList<>();
	
	public final static int TBK_TRPC_USERINFO_LINE_LENGHT = 131;
	public final static int TBK_TRPC_USERRESTRICTION_LINE_LENGHT = 25;
	public final static int TBK_TRPC_USERAUTONOMY_LINE_LENGHT = 41;
	public final static int TBK_TRPC_USERCROSSREFERENCE_LINE_LENGHT = 41;

	public final static int TBK_TRPC_SESSION_NAME_LENGHT = 20;

	public TRPCOutput() {
	}

	public TRPCOutput(String output) {
		setStringBody(output);
	}
	
	public String getSessionName() {
		return sessionName;
	}


	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public List<TRPCUserInfoFileOutput> getTrpcUserInfoFileOutput() {
		return trpcUserInfoFileOutput;
	}

	public void setTrpcUserInfoFileOutput(List<TRPCUserInfoFileOutput> trpcUserInfoFileOutput) {
		this.trpcUserInfoFileOutput = trpcUserInfoFileOutput;
	}

	public List<TRPCUserRestrictionsFileOutput> getTrpcUserRestrictionsFileOutput() {
		return trpcUserRestrictionsFileOutput;
	}

	public void setTrpcUserRestrictionsFileOutput(List<TRPCUserRestrictionsFileOutput> trpcUserRestrictionsFileOutput) {
		this.trpcUserRestrictionsFileOutput = trpcUserRestrictionsFileOutput;
	}

	public List<TRPCUserAutonomiesFileOutput> getTrpcUserAutonomiesFileOutput() {
		return trpcUserAutonomiesFileOutput;
	}

	public void setTrpcUserAutonomiesFileOutput(List<TRPCUserAutonomiesFileOutput> trpcUserAutonomiesFileOutput) {
		this.trpcUserAutonomiesFileOutput = trpcUserAutonomiesFileOutput;
	}

	public List<TRPCUserCrossReferencesFileOutput> getTrpcUserCrossReferenceFileOutput() {
		return trpcUserCrossReferenceFileOutput;
	}

	public void setTrpcUserCrossReferenceFileOutput(
			List<TRPCUserCrossReferencesFileOutput> trpcUserCrossReferenceFileOutput) {
		this.trpcUserCrossReferenceFileOutput = trpcUserCrossReferenceFileOutput;
	}

	@Override
	public String getStringBody() {
		return null;
	}

	@Override
	public void setStringBody(String output) {
		int i=0;
		setSessionName(output.substring(i, i += TBK_TRPC_SESSION_NAME_LENGHT));
	}

	@Override
	public void readFile(File file) {
		
		try (BufferedReader in = Files.newBufferedReader(file.toPath(), Charset.forName("Cp1252"))) {
			String line = null;
			while ((line = in.readLine()) != null) {
				String indicator = line.substring(0, 3);
				
				if ("USU".equals(indicator))
				{
					line = StringUtils.rightPad(line, TBK_TRPC_USERINFO_LINE_LENGHT, StringUtils.SPACE);
					TRPCUserInfoFileOutput userInfo = new TRPCUserInfoFileOutput(line);
					this.trpcUserInfoFileOutput.add(userInfo);
				}
				else if ("OMI".equals(indicator))
				{
					line = StringUtils.rightPad(line, TBK_TRPC_USERRESTRICTION_LINE_LENGHT, StringUtils.SPACE);
					TRPCUserRestrictionsFileOutput userRestriccion = new TRPCUserRestrictionsFileOutput(line);
					this.trpcUserRestrictionsFileOutput.add(userRestriccion);
				}
				else if ("AUT".equals(indicator))
				{
					line = StringUtils.rightPad(line, TBK_TRPC_USERAUTONOMY_LINE_LENGHT, StringUtils.SPACE);
					TRPCUserAutonomiesFileOutput userAutonomies = new TRPCUserAutonomiesFileOutput(line);
					this.trpcUserAutonomiesFileOutput.add(userAutonomies);
				}
				else
				{
					line = StringUtils.rightPad(line, TBK_TRPC_USERCROSSREFERENCE_LINE_LENGHT, StringUtils.SPACE);
					TRPCUserCrossReferencesFileOutput userCrossReference = new TRPCUserCrossReferencesFileOutput(line);
					this.trpcUserCrossReferenceFileOutput.add(userCrossReference);
				}
			}
		} catch (IOException e) {
			// TODO: handle exception
		}
	}


}
