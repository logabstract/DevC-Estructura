package pe.com.scotiabank.tbk.admin.trama.input;

import pe.com.scotiabank.tbk.admin.trama.util.Body;
import pe.com.scotiabank.tbk.admin.trama.util.Functions;

public class TRPCInput implements Body {
	
	private String contract;
	private String userCode;
	
	public final static int TBK_TRPC_CONTRACT_LENGHT = 5;
	public final static int TBK_TRPC_USERCODE_LENGHT = 3;
	
	public TRPCInput() {
	}

	public TRPCInput(String contract, String userCode) {
		super();
		this.contract = contract;
		this.userCode = userCode;
	}
	
	public String getContract() {
		return contract;
	}

	public void setContract(String contract) {
		this.contract = Functions.truncateLeftWithZeros(contract, TBK_TRPC_CONTRACT_LENGHT);
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = Functions.truncateLeftWithZeros(userCode, TBK_TRPC_USERCODE_LENGHT);
	}

	@Override
	public String getStringBody() {
		StringBuilder builder = new StringBuilder();
		builder.append(contract).append(userCode);
		return builder.toString();
	}

	@Override
	public void setStringBody(String output) {
	}

}
