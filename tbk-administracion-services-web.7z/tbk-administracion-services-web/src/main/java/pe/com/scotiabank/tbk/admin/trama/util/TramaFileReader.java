package pe.com.scotiabank.tbk.admin.trama.util;

import java.io.File;

public interface TramaFileReader {
	
	public void readFile(File file);

}
