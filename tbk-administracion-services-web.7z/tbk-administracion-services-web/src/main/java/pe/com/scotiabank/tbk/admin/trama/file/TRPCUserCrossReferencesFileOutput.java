package pe.com.scotiabank.tbk.admin.trama.file;

import pe.com.scotiabank.tbk.admin.trama.util.Body;

public class TRPCUserCrossReferencesFileOutput implements Body{

	//Referencias cruzadas
	private String user1;
	private String user2;
	private String paymentType;
	private String crossRefPEN;
	private String crossRefUSD;
	
	public static final int TBK_TRPC_USER1_LENGHT = 3;
	public static final int TBK_TRPC_USER2_LENGHT = 3;
	public static final int TBK_TRPC_PAYMENTTYPE_LENGHT = 2;
	public static final int TBK_TRPC_CROSSREFPEN_LENGHT = 9;
	public static final int TBK_TRPC_CROSSREFUSD_LENGHT = 9;
	
	public TRPCUserCrossReferencesFileOutput(String line) {
		setStringBody(line);
	}

	public String getUser1() {
		return user1;
	}

	public void setUser1(String user1) {
		this.user1 = user1;
	}

	public String getUser2() {
		return user2;
	}

	public void setUser2(String user2) {
		this.user2 = user2;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getCrossRefPEN() {
		return crossRefPEN;
	}

	public void setCrossRefPEN(String crossRefPEN) {
		this.crossRefPEN = crossRefPEN;
	}

	public String getCrossRefUSD() {
		return crossRefUSD;
	}

	public void setCrossRefUSD(String crossRefUSD) {
		this.crossRefUSD = crossRefUSD;
	}

	@Override
	public String getStringBody() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setStringBody(String output) {
		int i=3;
		setUser1(output.substring(i, i+=TBK_TRPC_USER1_LENGHT));
		setUser2(output.substring(i, i+=TBK_TRPC_USER2_LENGHT));
		setPaymentType(output.substring(i, i+=TBK_TRPC_PAYMENTTYPE_LENGHT));
		setCrossRefPEN(output.substring(i, i+=TBK_TRPC_CROSSREFPEN_LENGHT));
		setCrossRefUSD(output.substring(i, i+=TBK_TRPC_CROSSREFPEN_LENGHT));
	}

	@Override
	public String toString() {
		return "TRPCUserCrossReferencesFileOutput [user1=" + user1 + ", user2=" + user2 + ", paymentType=" + paymentType
				+ ", crossRefPEN=" + crossRefPEN + ", crossRefUSD=" + crossRefUSD + "]\n";
	}
	
}