package pe.com.scotiabank.tbk.admin.trama.file;

import pe.com.scotiabank.tbk.admin.trama.util.Body;

public class TRPCUserRestrictionsFileOutput implements Body {

	//Restricciones de menu/cuentas
	private String user;
	private String type;
	private String categoryCode;
	private String sequence;
	
	public static final int TBK_TRPC_USER_LENGHT = 3;
	public static final int TBK_TRPC_TYPE_LENGHT = 2;
	public static final int TBK_TRPC_CATEGORYCODE_LENGHT = 14;
	public static final int TBK_TRPC_SEQUENCE_LENGHT = 3;
	
	public TRPCUserRestrictionsFileOutput(String line) {
		setStringBody(line);
	}
	
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	@Override
	public String getStringBody() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setStringBody(String output) {
		int i=3;
		setUser(output.substring(i, i+=TBK_TRPC_USER_LENGHT));
		setType(output.substring(i, i+=TBK_TRPC_TYPE_LENGHT));
		setCategoryCode(output.substring(i, i+=TBK_TRPC_CATEGORYCODE_LENGHT));
		setSequence(output.substring(i, i+=TBK_TRPC_SEQUENCE_LENGHT));
	}

	@Override
	public String toString() {
		return "TRPCUserRestrictionsFileOutput [user=" + user + ", type=" + type + ", categoryCode=" + categoryCode
				+ ", sequence=" + sequence + "]\n";
	}
	

}
