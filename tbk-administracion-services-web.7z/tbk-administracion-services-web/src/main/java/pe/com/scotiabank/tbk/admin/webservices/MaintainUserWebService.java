package pe.com.scotiabank.tbk.admin.webservices;

import javax.jws.WebService;

@WebService(name = "MaintainUserWebService")
public interface MaintainUserWebService {
	
	

}
