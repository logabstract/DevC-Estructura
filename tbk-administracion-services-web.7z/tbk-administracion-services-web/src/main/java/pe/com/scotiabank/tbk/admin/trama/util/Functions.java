package pe.com.scotiabank.tbk.admin.trama.util;

import org.apache.commons.lang3.StringUtils;

public class Functions {
	
	public enum PaddingDirection {
		LEFT, RIGHT
	}
	
	public static String truncateLeftWithZeros(String s, int length)
	{
		return truncateAndPad(s, "0", PaddingDirection.LEFT, length);
	}
	
	public static String truncateRightWithZeros(String s, int length)
	{
		return truncateAndPad(s, "0", PaddingDirection.RIGHT, length);
	}
	
	public static String truncateLeftWithSpaces(String s, int length)
	{
		return truncateAndPad(s, StringUtils.SPACE, PaddingDirection.LEFT, length);
	}
	
	public static String truncateRightWithSpaces(String s, int length)
	{
		return truncateAndPad(s, StringUtils.SPACE, PaddingDirection.RIGHT, length);
	}
	
	public static String truncateAndPad(String s, String padValue, PaddingDirection direction, int length)
	{
		if (StringUtils.isBlank(s))
		{
			return StringUtils.repeat(padValue,length);
		}
		else
		{
			if (direction == PaddingDirection.LEFT)
			{
				return StringUtils.left(StringUtils.leftPad(StringUtils.stripStart(StringUtils.strip(s), "0"), length, padValue), length);
			}
			else
			{
				return StringUtils.left(StringUtils.rightPad(StringUtils.strip(s),length,padValue), length);
			}
		}
	}
}
