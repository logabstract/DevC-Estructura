package pe.com.scotiabank.tbk.admin.trama.output;

import java.io.File;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

public class TRPCOutputTest {

	@Test
	public void testReadFile() {
		
		File file = new File("D:/TRPC.txt");
		
		if (file.exists())
		{
			TRPCOutput trpc = new TRPCOutput();
			
			trpc.readFile(file);
			
			System.out.println("(" + StringUtils.join(trpc.getTrpcUserInfoFileOutput(), ",") + ")");
			System.out.println("(" + StringUtils.join(trpc.getTrpcUserRestrictionsFileOutput(), ",") + ")");
			System.out.println("(" + StringUtils.join(trpc.getTrpcUserAutonomiesFileOutput(), ",") + ")");
			System.out.println("(" + StringUtils.join(trpc.getTrpcUserCrossReferenceFileOutput(), ",") + ")");
		}
	}
}
